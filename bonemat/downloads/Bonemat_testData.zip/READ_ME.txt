Realistic subfolder

	These are realistic data, released for practicing with Bonemat. They consist of two files and a folder:

	CT_dataset is a folder containing a fully anonymised CT of the proximal femur, taken from a cohort of osteopoenic or osteoporotic postmenopausal women, in DICOM format.

	Mesh.cdb is a FE mesh of the right femur superimposed to the CT volume, in Ansys archive format.

	Configuration_file.xml contains all the Bonemat operation parameters, as specified in the paper: Schileo et al. J Biomech 47:3531-8, 2014. 


Simple subfolder

	These are simple, debug data to test Bonemat. They consist of four files:
	
	Volume.vtk is an artificial simple volume.
	
	Elements.lis and Nodes.lis contain data of a 10-element mesh in Generic Mesh Format.
	
	Configuration_file.xml contains all the Bonemat operation parameters, as specified in the paper: Schileo et al. J Biomech 47:3531-8, 2014. 
